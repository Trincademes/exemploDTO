package com.example.demo.dto;

public record LivroDTO(Long id, String titulo, String autor) {
	
}
